package com.example.splashandlogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    private Button register;
    private EditText Email;
    private EditText Password;
    private EditText PersonName;
    private EditText Phone;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        register =(Button)findViewById(R.id.login);
        PersonName =(EditText)findViewById(R.id.name);
        Email =(EditText)findViewById(R.id.email);
        Password =(EditText)findViewById(R.id.password);
        Phone =(EditText)findViewById(R.id.phonenumber);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Name=PersonName.getText().toString();
                final String email=Email.getText().toString();
                final String password=Password.getText().toString();
                final String number=Phone.getText().toString();
                boolean emailValidator;
                if(Name.length()==0 ||email.length()==0 ||password.length()==0 ||number.length()==0 )
                {
                    Toast.makeText(Register.this,"A field cannot be empty",Toast.LENGTH_LONG).show();
                }
                else if(!Name.matches("[a-zA-Z ]+"))
                {
                    PersonName.requestFocus();
                    PersonName.setError("ENTER ONLY ALPHABETICAL CHARACTER");
                }
                else if(!number.matches("[0-9]+"))
                {
                    Phone.requestFocus();
                    Phone.setError("ENTER ONLY NUMBERS ");
                }
                else if(!emailValidator(email))
                {
                        Email.requestFocus();
                    Email.setError(" Give correct format (xyz@xyzdomain.com) ");
                }
                else
                {
                    Toast.makeText(Register.this,"Validation Successful",Toast.LENGTH_LONG).show();
                }
            }
            public boolean emailValidator(String email)
            {
                Pattern pattern;
                Matcher matcher;
                final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                pattern = Pattern.compile(EMAIL_PATTERN);
                matcher = pattern.matcher(email);
                return matcher.matches();
            }
        });
    }
}



